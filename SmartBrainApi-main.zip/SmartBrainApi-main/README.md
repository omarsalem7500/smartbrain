# SmartBrain-api - v1

** Make sure you use postgreSQL instead of mySQL for this code base.
